(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.4f212306.js")
    );
  })().catch(console.error);

})();
