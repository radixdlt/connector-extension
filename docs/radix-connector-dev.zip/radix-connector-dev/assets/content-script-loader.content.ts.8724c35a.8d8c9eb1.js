(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.8724c35a.js")
    );
  })().catch(console.error);

})();
