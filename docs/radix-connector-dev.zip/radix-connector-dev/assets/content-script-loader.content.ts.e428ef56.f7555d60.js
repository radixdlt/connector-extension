(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.e428ef56.js")
    );
  })().catch(console.error);

})();
