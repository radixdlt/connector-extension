(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.74bec503.js")
    );
  })().catch(console.error);

})();
