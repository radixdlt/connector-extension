(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.aa0902ad.js")
    );
  })().catch(console.error);

})();
