(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.183cc7b3.js")
    );
  })().catch(console.error);

})();
