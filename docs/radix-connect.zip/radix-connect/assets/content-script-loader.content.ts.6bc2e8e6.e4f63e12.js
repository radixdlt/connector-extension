(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.6bc2e8e6.js")
    );
  })().catch(console.error);

})();
