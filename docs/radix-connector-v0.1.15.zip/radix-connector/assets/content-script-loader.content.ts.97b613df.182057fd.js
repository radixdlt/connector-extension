(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.97b613df.js")
    );
  })().catch(console.error);

})();
