(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content.ts.ba76f0d0.js")
    );
  })().catch(console.error);

})();
